from django.contrib import admin

from teacher.models import TeacherAssign

admin.site.register(TeacherAssign)
