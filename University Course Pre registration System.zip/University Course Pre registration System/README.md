# University-Course-Pre-registration-System-Python-Django-Project
University course pre-registration system is built using Python django framework and sqlite3 database. 
By this system university authority can know in advance how much student will take a particular course. 
Based upon that they can merge a section and predict how many instructor will be required. 
It will be helpful to assign retaken student to a section.

It's our group project.We build this project in our software development course.
I added code,presentation slide and project proposal in this repository.
